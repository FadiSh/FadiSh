//
//  PushwooshInboxUI.h
//  PushwooshInboxUI
//
//  Created by Pushwoosh on 01/11/2017.
//  Copyright © 2017 Pushwoosh. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PushwooshInboxUI.
FOUNDATION_EXPORT double PushwooshInboxUIVersionNumber;

//! Project version string for PushwooshInboxUI.
FOUNDATION_EXPORT NSString * const PushwooshInboxUIVersion;

#import "PWIInboxUI.h"
#import "PWIInboxStyle.h"

